Thank you for downloading Chunky Zorvy Font!

📁 Files included:
- ChunkyZorvy Regular.otf
  Chunky Zorvy is a bold and quirky chunky display typeface that brings playful energy, funky shapes, and expressive character to modern visual design. Inspired by retro graphic aesthetics and reinterpreted with a contemporary attitude, Chunky Zorvy combines heavy letterforms, playful distortion, rounded and angular details, and an irregular rhythm to create typography that feels bold, fun, distinctive, and memorable.

- License - Free for personal use.txt

🛠 How to install:
- Double-click the font file and click “Install”
- Or drag the .otf file into your Fonts folder (Windows/Mac)

📌 License:
>> You downloaded the Free for personal use license.
>> For Commercial use & full version:
   https://syauqistudio.gumroad.com/l/chunkyzorvy


📬 Contact:
Email: syauqistudios@gmail.com

Follow me for more fonts & updates:
Instagram: @syauqistudio
Behance: behance.net/syauqistudio

Enjoy and tag me if you use it!